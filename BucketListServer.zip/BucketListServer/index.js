const express = require('express')
const app = express()
const port = 3000

app.use(express.json())
app.use(express.urlencoded({extended:false}))

let id = 1
let tasks = [
    {
        id:0,
        objective:"blah blah blah",
        createdAt:`${Date()}`
    }
]

app.get('/', (req, res) => {
  res.send('Hello World!')
})

app.get('/tasks', (req,res) => {
    res.send(tasks)
})

app.post('/tasks', (req,res) => {
    tasks.push({
        id:id++,
        objective:req.body.objective,
        createdAt:`${Date()}`
    })
    res.send(tasks)
})

app.patch('/tasks/:taskID',(req,res) => {
    let task = tasks.find(e => e.id == parseInt(req.params.taskID))
    task.objective = req.body.objective
    res.send(tasks)
})

app.delete('/tasks/:taskID',(req,res) => {
    tasks = tasks.filter(e => e.id != parseInt(req.params.taskID))    
    res.send(tasks)
})

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
})